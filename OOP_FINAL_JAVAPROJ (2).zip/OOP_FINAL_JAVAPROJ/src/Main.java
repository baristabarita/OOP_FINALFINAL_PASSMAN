import GUI.*;

public class Main {
    public static void main(String[] args) throws Exception {
        PmMockupUI theView = new PmMockupUI();
    }
}   
